$('.gallery .hero:first-child').addClass('shown');

$('.next').on('click', function(e) {

	if ($('.shown').is(':last-child') ) {
		$('.shown').removeClass('shown').parent().first().addClass('shown');

	} 

	else {

	$('.shown').removeClass('shown').next().addClass('shown');

	}

	var caption = $('.shown').attr('title');
	$('.name').text(caption).show().fadeOut(10000);
});

/*$(document).ready(function(){
//	$(".gallery").addClass('active');
	$('img:first').addClass('shown');
	$('.name').text('Batman');

});


//	$('img:second').addClass('shown');
//	$('.name').text('captain');

//});

$('.next').on('click', function(e){
	$('next').addClass('shown');
	$('.name').text('Captain America');

});
*/